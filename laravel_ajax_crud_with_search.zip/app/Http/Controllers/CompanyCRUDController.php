<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;
use Datatables;
use Illuminate\Support\Facades\DB;

class CompanyCRUDController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (request()->ajax()) {
            if (!empty($request->filter_status)) {
                $data = DB::table('tasks')
                    ->select('*')
                    ->where('status', $request->filter_status)
                    ->get();
            } else if (!empty($request->filter_name)) {
                $data = DB::table('tasks')
                    ->select('*')
                    ->where('name', $request->filter_name)
                    ->get();
            } else if (!empty($request->filter_priority)) {
                $data = DB::table('tasks')
                    ->select('*')
                    ->where('priority', $request->filter_priority)
                    ->get();
            } else {
                $data = DB::table('tasks')
                    ->select('*')
                    ->get();
            }
            return datatables()->of($data)
                ->addColumn('action', 'tasks.action')
                ->addColumn('priority', function ($row1) {
                    if ($row1->priority == 1) {
                        return 'High';
                    } else if($row1->priority == 2) {
                        return 'Low';
                    }
                })
                ->addColumn('status', function ($row) {
                    if ($row->status == 1) {
                        return 'to-do';
                    } else if ($row->status == 2) {
                        return 'In Progress';
                    } else if ($row->status == 3) {
                        return 'Completed';
                    }
                })
                ->filter(function ($instance1) use ($request) {
                    if ($request->get('priority') == '1' || $request->get('priority') == '2') {
                        $instance1->where('priority', $request->get('priority'));
                    }
                })
                ->filter(function ($instance) use ($request) {
                    if ($request->get('status') == '0' || $request->get('status') == '1' || $request->get('status') == '2') {
                        $instance->where('status', $request->get('status'));
                    }
                })
                ->rawColumns(['priority'],['status'],['action'])
                // ->addColumn('status', 'tasks.status')
                // ->addColumn('action', 'tasks.action')
                // ->rawColumns(['status'],['action'])
                ->addIndexColumn()
                ->make(true);
        }
        $task_name = DB::table('tasks')
            ->select('name')
            ->groupBy('name')
            ->orderBy('name', 'ASC')
            ->get();
        return view('tasks.index', compact('task_name'));
    }
    // public function status(Request $request)
    // {
    //     $status = DB::table('tasks')
    //     ->get()->where('id',1);
    //     return $status;
    // }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tasks.create');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'priority' => 'required',
            'status' => 'required'
        ]);
        $company = new Task;
        $company->name = $request->name;
        $company->priority = $request->priority;
        $company->status = $request->status;
        $company->save();
        return redirect()->route('tasks.index')
            ->with('success', 'Record has been created successfully.');
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\company  $company
     * @return \Illuminate\Http\Response
     */
    public function show(Task $task)
    {
        return view('tasks.show', compact('task'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Task  $company
     * @return \Illuminate\Http\Response
     */
    public function edit(Task $task)
    {
        return view('tasks.edit', compact('task'));
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\company  $company
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'priority' => 'required',
            'status' => 'required'
        ]);
        $task = Task::find($id);
        $task->name = $request->name;
        $task->priority = $request->priority;
        $task->status = $request->status;
        $task->save();
        return redirect()->route('tasks.index')
            ->with('success', 'Record Has Been updated successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Task  $company
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        Task::where('id', $request->id)->delete();
        return redirect()->route('tasks.index')
            ->with('success', 'Record Has Been deleted successfully');
    }
}
