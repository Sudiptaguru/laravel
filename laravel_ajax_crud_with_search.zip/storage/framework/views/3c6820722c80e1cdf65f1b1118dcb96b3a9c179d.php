<!DOCTYPE html>
<html>
<head>
    <title>Reminder</title>
</head>
<body>
    <h1><?php echo e($details['reminder']); ?></h1>
    <p><?php echo e($details['date']); ?></p>

    <p>Thank you</p>
</body>
</html>
<?php /**PATH C:\Users\Sudipta Guru\Desktop\laravel\larablog\resources\views/emails/myTestMail.blade.php ENDPATH**/ ?>