<a href="<?php echo e(route('tasks.show',$id)); ?>" data-toggle="tooltip" data-original-title="Edit" class="show btn btn-info show">
    Show
</a>
<a href="<?php echo e(route('tasks.edit',$id)); ?>" data-toggle="tooltip" data-original-title="Edit" class="edit btn btn-success edit">
    Edit
</a>
<a href="javascript:void(0)" data-id="<?php echo e($id); ?>" data-toggle="tooltip" data-original-title="Delete" class="delete btn btn-danger">
    Delete
</a>
<?php /**PATH C:\Users\Sudipta Guru\Desktop\laravel\larablog\resources\views/tasks/action.blade.php ENDPATH**/ ?>