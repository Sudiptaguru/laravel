@foreach($status as $name)
<!-- {{ $name->status }} -->
<?php
if($name->status=='0')
{
	echo 'to-do';
}
else if($name->status=='1')
{
	echo 'In Progress';
}
else if($name->status=='2')
{
	echo 'Completed';
}
?>
@endforeach