<a href="{{ route('tasks.show',$id) }}" data-toggle="tooltip" data-original-title="Edit" class="show btn btn-info show">
    Show
</a>
<a href="{{ route('tasks.edit',$id) }}" data-toggle="tooltip" data-original-title="Edit" class="edit btn btn-success edit">
    Edit
</a>
<a href="javascript:void(0)" data-id="{{ $id }}" data-toggle="tooltip" data-original-title="Delete" class="delete btn btn-danger">
    Delete
</a>
