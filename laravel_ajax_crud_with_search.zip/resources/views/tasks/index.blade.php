@extends('layouts.app')

@section('content')
<div class="container mt-2">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 8 CRUD using DataTables</h2>
            </div>
            <div class="pull-right mb-2">
                <a class="btn btn-success" href="{{ route('tasks.create') }}"> Create Task</a>
            </div>
        </div>
    </div>
    @if ($message = Session::get('success'))
    <div class="alert alert-success">
        <p>{{ $message }}</p>
    </div>
    @endif
    <br />
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="form-group">
                <select name="filter_status" id="filter_status" class="form-control" required>
                    <option value="">Select Status</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
            <div class="form-group">
                <select name="filter_priority" id="filter_priority" class="form-control" required>
                    <option value="">Select Priority</option>
                    <option value="High">High</option>
                    <option value="Low">Low</option>
                </select>
            </div>
            <div class="form-group">
                <select name="filter_name" id="filter_name" class="form-control" required>
                    <option value="">Select name</option>
                    @foreach($task_name as $name)

                    <option value="{{ $name->name }}">{{ $name->name }}</option>

                    @endforeach
                </select>
            </div>

            <div class="form-group" align="center">
                <button type="button" name="filter" id="filter" class="btn btn-info">Filter</button>

                <button type="button" name="reset" id="reset" class="btn btn-default">Reset</button>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div>
    <br />
    <div class="card-body">
        <table class="table table-bordered" id="datatable-crud">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <!-- <th>Created at</th> -->
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        fill_datatable();
        // fill_datatable1();
        // fill_datatable2();
        function fill_datatable(filter_status = '', filter_name = '', filter_priority = '') {
            $('#datatable-crud').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "tasks",
                    // data: {
                    //     filter_status: filter_status
                    // }
                    data: function(d) {
                        d.filter_status = $('#filter_status').val(),
                            d.filter_name = $('#filter_name').val(),
                            d.filter_priority = $('#filter_priority').val(),
                            d.search = $('input[type="search"]').val()
                    }
                },
                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'priority',
                        name: 'priority'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    // {
                    //     data: 'created_at',
                    //     name: 'created_at'
                    // },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false
                    },
                ],
                order: [
                    [0, 'desc']
                ]
            });
            $('body').on('click', '.delete', function() {
                if (confirm("Delete Record?") == true) {
                    var id = $(this).data('id');
                    // ajax
                    $.ajax({
                        type: "POST",
                        url: "{{ url('delete-company') }}",
                        data: {
                            id: id
                        },
                        dataType: 'json',
                        success: function(res) {
                            var oTable = $('#datatable-crud').dataTable();
                            oTable.fnDraw(false);
                        }
                    });
                }
            });
        }
        $('#filter').click(function() {
            var filter_status = $('#filter_status').val();
            var filter_name = $('#filter_name').val();
            var filter_priority = $('#filter_priority').val();
            if (filter_status != '') {
                $('#datatable-crud').DataTable().destroy();
                fill_datatable(filter_status);
            } else if (filter_name != '') {
                $('#datatable-crud').DataTable().destroy();
                fill_datatable(filter_name);
            } else if (filter_priority != '') {
                $('#datatable-crud').DataTable().destroy();
                fill_datatable(filter_priority);
            }
        });

        $('#reset').click(function() {
            $('#filter_status').val('');
            $('#filter_name').val('');
            $('#filter_priority').val('');
            $('#datatable-crud').DataTable().destroy();
            fill_datatable();
            $('#datatable-crud').DataTable().destroy();
            fill_datatable();
            $('#datatable-crud').DataTable().destroy();
            fill_datatable();
        });
    });
</script>
@endsection
