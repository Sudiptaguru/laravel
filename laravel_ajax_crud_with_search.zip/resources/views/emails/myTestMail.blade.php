<!DOCTYPE html>
<html>
<head>
    <title>Reminder</title>
</head>
<body>
    <h1>{{ $details['reminder'] }}</h1>
    <p>{{ $details['date'] }}</p>

    <p>Thank you</p>
</body>
</html>
